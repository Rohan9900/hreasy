# Easy HR Admin Panel 




Easy HR - A Complete HR Institution.Premium HR Solution For SME's and Enterprises. Successfully move your employee information from spreadsheets to an easy to use HR software and do more with your time.

