import * as React from 'react';
import clsx from 'clsx';
import { styled } from '@mui/system';
import { useSwitch } from '@mui/core/SwitchUnstyled';
import { useDispatch, useSelector } from 'react-redux';
import { addAttendence } from '../store/actions/attendenceAction';

const BasicSwitchRoot = styled('span')`
    font-size: 0;
    position: relative;
    display: inline-block;
    width: 58px;
    height: 30px;
    background: #b3c3d3;
    border-radius: 37px;
    margin: 10px;
    cursor: pointer;

    &.Switch-disabled {
        opacity: 0.4;
        cursor: not-allowed;
    }

    &.Switch-checked {
        background: #007fff;
    }
`;

const BasicSwitchInput = styled('input')`
    cursor: inherit;
    position: absolute;
    width: 100%;
    height: 100%;
    top: 0;
    left: 0;
    opacity: 0;
    z-index: 1;
    margin: 0;
`;

const BasicSwitchThumb = styled('span')`
    display: block;
    width: 25px;
    height: 24px;
    top: 3px;
    left: 3px;
    border-radius: 16px;
    background-color: #fff;
    position: relative;
    transition: all 200ms ease;

    &.Switch-focusVisible {
        background-color: rgba(255, 255, 255, 1);
        box-shadow: 0 0 1px 8px rgba(0, 0, 0, 0.25);
    }

    &.Switch-checked {
        left: 28px;
        top: 3px;
        background-color: #fff;
    }
`;

export default function BasicSwitch(props) {
    const { getInputProps, checked, focusVisible } = useSwitch(props);
    const { data, date, page, disabled, largest } = props;
    const [state, setState] = React.useState(true);
    const dispatch = useDispatch();
    React.useEffect(() => {
        if (disabled === false && page > largest) {
            dispatch(
                addAttendence({
                    UAN: data?.companyDetails?.UAN,
                    fullName: data?.personalDetails?.fullName,
                    mobileNo: data?.personalDetails?.mobileNo,
                    joiningDate: data?.companyDetails?.joiningDate,
                    designation: data?.companyDetails?.designation,
                    dailyWages: data?.companyDetails?.dailyWages,
                    employeeAttendance: { date: date?.getDate(), attendance: true },
                    attendanceMonth: date?.getMonth() + 1,
                    attendanceYear: date?.getFullYear(),
                    /* eslint no-underscore-dangle: 0 */
                    employee: data?._id
                })
            );
        }
    }, [disabled, page]);

    const x = true;
    const handleSwitchChange = (e) => {
        dispatch(
            addAttendence({
                UAN: data?.companyDetails?.UAN,
                fullName: data?.personalDetails?.fullName,
                mobileNo: data?.personalDetails?.mobileNo,
                joiningDate: data?.companyDetails?.joiningDate,
                designation: data?.companyDetails?.designation,
                dailyWages: data?.companyDetails?.dailyWages,
                employeeAttendance: { date: date?.getDate(), attendance: e.target.checked },
                attendanceMonth: date?.getMonth(),
                attendanceYear: date?.getFullYear(),
                /* eslint no-underscore-dangle: 0 */
                employee: data?._id
            })
        );
        setState(e.target.checked);
    };
    const stateClasses = {
        'Switch-checked': checked,
        'Switch-disabled': disabled,
        'Switch-focusVisible': focusVisible
    };
    console.log(page);

    return (
        <BasicSwitchRoot className={clsx(stateClasses)} checked={state} defaultChecked={x} onChange={handleSwitchChange}>
            <BasicSwitchThumb className={clsx(stateClasses)} />
            <BasicSwitchInput {...getInputProps()} aria-label="Demo switch" />
        </BasicSwitchRoot>
    );
}
